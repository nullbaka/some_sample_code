"""Calculates and plots the top 10 most economic bowlers"""

import csv
import operator
import matplotlib.pyplot as plt

from ipl_lib import path
from ipl_lib import match_ids_of


def all_deliveries_dict(season):
    """Extracts delivery data from the deliveries.csv file"""
    PATH = path()
    match_ids = match_ids_of(season)

    all_deliveries = {}

    total_balls = 'total_balls'
    total_runs = 'total_runs'

    with open(PATH + '/ipl/deliveries.csv') as deliveries_file:
        deliveries_reader = csv.DictReader(deliveries_file)

        for delivery in deliveries_reader:

            match_id = delivery['match_id']
            is_super_over = delivery['is_super_over']
            bowler = delivery['bowler']
            noball = int(delivery['noball_runs'])
            if noball > 0:
                noball = 1
            wide_ball = int(delivery['wide_runs'])
            if wide_ball > 0:
                wide_ball = 1
            bye_runs = int(delivery['bye_runs'])
            legbye_runs = int(delivery['legbye_runs'])
            total = int(delivery['total_runs'])

            if match_id in match_ids and is_super_over != '1':
                if bowler in all_deliveries:
                    all_deliveries[bowler][total_balls] += 1 - noball - wide_ball
                    all_deliveries[bowler][total_runs] += total - bye_runs -legbye_runs

                else:
                    all_deliveries[bowler] = {}
                    all_deliveries[bowler][total_balls] = 1 - noball - wide_ball
                    all_deliveries[bowler][total_runs] = total - bye_runs - legbye_runs

    return all_deliveries


def bowler_economy_dict(season):
    """Calculate the economy of all the bowlers"""
    all_deliveries = all_deliveries_dict(season)

    bowler_economy = {}

    for bowler, stats in all_deliveries.items():
        bowler_economy[bowler] = stats['total_runs']/stats['total_balls']*6

    return bowler_economy


def top_10_bowlers(season):
    """Pick top 10 most economic bowlers from all the bowlers"""
    bowler_economy = bowler_economy_dict(season)

    bowler_economy_ordered = sorted(bowler_economy.items(), key=operator.itemgetter(1))

    return bowler_economy_ordered[:10]


def plot_top_bowlers(season):
    """Plot the top 10 most econommic bowlers and their economy into a bar chart"""
    top_bowlers = top_10_bowlers(season)

    bowler_name = [name[0] for name in top_bowlers]
    bowler_economy = [economy[1] for economy in top_bowlers]

    plt.barh(bowler_name, bowler_economy)
    plt.title("Top 10 economic bowlers of {}".format(season))
    plt.xlabel("Bowling economy")
    plt.show()

plot_top_bowlers('2015')

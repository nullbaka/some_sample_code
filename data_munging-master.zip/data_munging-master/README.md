Two datasets were taken, football.dat and weather.dat

For football.dat, the minimum difference of for and against goals were calculated
and the corresponding team was printed.

For weather.dat, the minimum difference of minimum and maximum temperatures were
calculated and the corresponding team was printed.

Modules were written keeping the SOLID principles in mind.

Run main.py for the result.
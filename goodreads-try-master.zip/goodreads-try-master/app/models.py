from app import db, login
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


read = db.Table('read', db.Column('id', db.Integer, db.ForeignKey(
    'user.id')), db.Column('book_id', db.Integer, db.ForeignKey('book.book_id')))
wishlist = db.Table('wishlist', db.Column('id', db.Integer, db.ForeignKey(
    'user.id')), db.Column('book_id', db.Integer, db.ForeignKey('book.book_id')))
now_reading = db.Table('now_reading', db.Column('id', db.Integer, db.ForeignKey(
    'user.id')), db.Column('book_id', db.Integer, db.ForeignKey('book.book_id')))


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    is_author = db.Column(db.Boolean, default=False)
    is_admin = db.Column(db.Boolean, default=False)
    reviews = db.relationship('Rating', backref='user', lazy='dynamic')

    read_books = db.relationship(
        'Book', secondary=read, backref=db.backref('read_user', lazy='dynamic'))
    wishlist_books = db.relationship(
        'Book', secondary=wishlist, backref=db.backref('wishlist_user', lazy='dynamic'))
    now_reading_books = db.relationship(
        'Book', secondary=now_reading, backref=db.backref('now_reading_user', lazy='dynamic'))

    def __repr__(self):
        return '<User {}>'.format(self.username)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def reading_status(self, book):
        status = 'unread'
        if book in self.read_books:
            status = 'read'
        elif book in self.wishlist_books:
            status = 'wishlist'
        elif book in self.now_reading_books:
            status = 'now_reading'
        return status

    def read(self, book):
        if self.reading_status(book) != 'read':
            self.read_books.append(book)
            if book in self.wishlist_books:
                self.wishlist_books.remove(book)
            elif book in self.now_reading_books:
                self.now_reading_books.remove(book)
            db.session.commit()

    def wishlist(self, book):
        if self.reading_status(book) != 'wishlist':
            self.wishlist_books.append(book)
            if book in self.read_books:
                self.read_books.remove(book)
            elif book in self.now_reading_books:
                self.now_reading_books.remove(book)
            db.session.commit()

    def now_reading(self, book):
        if self.reading_status(book) != 'now_reading':
            self.now_reading_books.append(book)
            if book in self.read_books:
                self.read_books.remove(book)
            elif book in self.wishlist_books:
                self.wishlist_books.remove(book)
            db.session.commit()

    def authorize_as_admin(self):
        self.is_admin = True
        db.session.commit()

    def deauthorize_as_admin(self):
        self.is_admin = False
        db.session.commit()

class Author(db.Model):
    author_id = db.Column(db.Integer, primary_key=True)
    author_name = db.Column(db.String(100), unique=True)
    about_author = db.Column(db.String(800))
    authored_books = db.relationship('Book', backref='author', lazy='dynamic')

    def __repr__(self):
        return '<Author {}>'.format(self.author_name)


class Book(db.Model):
    book_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150))
    summary = db.Column(db.String(800))
    genre = db.Column(db.String(20))
    author_id = db.Column(db.Integer, db.ForeignKey('author.author_id'))
    reviews = db.relationship('Rating', backref='book', lazy='dynamic')

    def __repr__(self):
        return '<Book {}>'.format(self.title)


class Rating(db.Model):
    rating_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    book_id = db.Column(db.Integer, db.ForeignKey('book.book_id'))
    review = db.Column(db.String(300))
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)


@login.user_loader
def load_user(id):
    return User.query.get(int(id))

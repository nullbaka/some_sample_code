from __future__ import absolute_import, unicode_literals
import os
from app import app, db, celery
from flask import render_template, flash, redirect, url_for, request, send_from_directory
from app.forms import LoginForm, RegistrationForm, AddBookForm, RateBookForm, AboutAuthorForm
from flask_login import current_user, login_user, logout_user, login_required
from app.models import User, Author, Book, Rating
from werkzeug.urls import url_parse


@app.route('/')
@app.route('/index')
@login_required
def index():
    return render_template('index.html', title="Recent updates")


@app.route('/login', methods=['GET', 'POST'])
def login():
    uttaran = User.query.first()
    if not uttaran:
        uttaran = User(username='uttaran', email='uttaran@email.com', is_admin=True)
        uttaran.set_password('cat')
        db.session.add(uttaran)
        db.session.commit()

    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index')
        flash(f'Hi {current_user.username}! You have just logged in.')
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)


@app.route('/logout')
def logout():
    logout_user()
    flash('You have successfully logged out.')
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash(f'Congratulations {form.username.data}, you are now a registered user! Please sign in to continue.')
        login_user(user)
        return redirect(url_for('index'))
    return render_template('register.html', title='Register', form=form)


@app.route('/add_book', methods=['GET', 'POST'])
@login_required
def add_book():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    form = AddBookForm()
    if form.validate_on_submit():
        author = Author.query.filter_by(author_name=form.author.data).first()
        book = Book.query.filter_by(title=form.title.data).first()
        if book is None:
            if author is None:
                author = Author(author_name=form.author.data)
                db.session.add(author)
                db.session.commit()
            book = Book(title=form.title.data,
                        summary=form.summary.data, author=author, genre=form.genre.data)
            db.session.add(book)
            db.session.commit()
        else:
            if author is None:
                author = Author(author_name=form.author.data)
                db.session.add(author)
                db.session.commit()
                book = Book(title=form.title.data,
                            summary=form.summary.data, author=author, genre=form.genre.data)
                db.session.add(book)
                db.session.commit()
        flash('A new book has been added. Add another book?')
        return redirect(url_for('add_book'))
    flash('add a new book here')
    return render_template('add_book.html', title="Add books", form=form)


@app.route('/explore')
def explore():
    books = Book.query.order_by(Book.book_id)
    return render_template('explore.html', title='Explore', books=books)


@app.route('/book/<book_title>/<author_id>', methods=['GET', 'POST'])
def book(book_title, author_id):
    book = Book.query.filter_by(title=book_title, author_id=author_id).first()
    form = RateBookForm()
    if form.validate_on_submit():
        if current_user.is_authenticated:
            review = Rating(user_id=current_user.id,
                            book_id=book.book_id, review=form.review.data)
            db.session.add(review)
            db.session.commit()
            return redirect(url_for('book', book_title=book.title, author_id=book.author.author_id))
        else:
            flash("You must be logged in to review.")
            return redirect(url_for('book', book_title=book.title, author_id=book.author.author_id))
    return render_template('book.html', title=book_title, book=book, form=form)


@app.route('/author/<author_name>')
def author(author_name):
    author = Author.query.filter_by(author_name=author_name).first()
    books = author.authored_books
    return render_template('author.html', title=author_name, author=author, books=books)


@app.route('/about_author/<author_name>', methods=['GET', 'POST'])
@login_required
def about_author(author_name):
    if not current_user.is_admin:
        return redirect(url_for('author', author_name=author_name))
    author = Author.query.filter_by(author_name=author_name).first()
    books = author.authored_books
    form = AboutAuthorForm()
    if form.validate_on_submit():
        author.about_author = form.about_author.data
        db.session.add(author)
        db.session.commit()
        return redirect(url_for('author', author_name=author_name))
    form.about_author.data = author.about_author
    return render_template('author.html', title=author_name, author=author, books=books, form=form)
    


@app.route('/read/<title>/<author_id>')
@login_required
def read(title, author_id):
    flash("This book has been added to your read books.")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.read(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))


@app.route('/wishlist/<title>/<author_id>')
@login_required
def wishlist(title, author_id):
    flash("This book has been added to your wishlist.")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.wishlist(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))


@app.route('/now_reading/<title>/<author_id>')
@login_required
def now_reading(title, author_id):
    flash("This book has been added to your currently reading books.")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.now_reading(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))


@app.route('/users')
@login_required
def users():
    users = User.query.all()
    return render_template('users.html', title="People", users=users)


@app.route('/user/<username>')
@login_required
def user(username):
    user = User.query.filter_by(username=username).first()
    return render_template('user.html', title=user.username, user=user)


@app.route('/authorize/<username>')
@login_required
def authorize(username):
    if current_user.is_admin:
        user = User.query.filter_by(username=username).first()
        user.authorize_as_admin()
    flash(f'{username} is now an admin.')
    return redirect(url_for('user', username=username))


@app.route('/deauthorize/<username>')
@login_required
def deauthorize(username):
    if current_user.is_admin:
        user = User.query.filter_by(username=username).first()
        if user.username != 'uttaran':
            user.deauthorize_as_admin()
            flash(f"{username}'s admin status has been revoked.")
    return redirect(url_for('user', username=username))


@celery.task
def create_log(username):
    user = User.query.filter_by(username=username).first()

    user_info = f"Username: {user.username}\nEmail: {user.email}\nis_admin: {user.is_admin}"
    
    user_read_books = "Read books:\n"
    for book in user.read_books:
        user_read_books += f"{book.title} by {book.author.author_name}\n"
    
    user_wishlist_books = "My wishlist:\n"
    for book in user.wishlist_books:
        user_wishlist_books += f"{book.title} by {book.author.author_name}\n"
    
    user_now_reading_books = "My current books:\n"
    for book in user.now_reading_books:
        user_now_reading_books += f"{book.title} by {book.author.author_name}\n"

    user_reviews = "My reviews:\n"
    for review in user.reviews:
        user_reviews += f"{review.book.title} by {review.book.author.author_name}:\n"
        user_reviews += f"   {review.review}\n\n"
    
    # file_path = os.path.expanduser(f"~/Desktop/{user.username}.txt")
    file_path = os.path.join(os.getcwd(), "app", "static", f"{user.username}.txt")

    if os.path.exists(file_path):
        os.remove(file_path)

    with open(file_path, "w") as f:
        f.write(user_info)
        f.write(user_read_books)
        f.write(user_wishlist_books)
        f.write(user_now_reading_books)
        f.write(user_reviews)
    
    source_dir = os.path.abspath(file_path)
    filename = f"{user.username}.txt"

    return send_from_directory(directory=source_dir, filename=filename, as_attachment=True)


@app.route('/generate_file/')
@login_required
def generate_file():
    username = current_user.username
    task = create_log.delay(username)
    return redirect(url_for('index'))


@app.route('/genre/<genre>')
def genre(genre):
    books = Book.query.filter_by(genre=genre)
    return render_template("genre.html", title=genre, books=books)
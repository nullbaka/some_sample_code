For this data assignment I transform raw data from IPL into data representable by graphs.

Found data csv files on https://www.kaggle.com/manasgarg/ipl


Extracted data for the following and plotted them -

1. The number of matches played per year of all the years in IPL.
2. Number of matches won by all teams over all the years of IPL.
3. For the year 2016, the extra runs conceded per team.
4. For the year 2015, the top economical bowlers.
5. For the Mumbai Indians, the number of successful chases, successful defenses and losses.
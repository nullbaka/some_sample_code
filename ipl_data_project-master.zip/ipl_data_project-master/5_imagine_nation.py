"""Compiles the wins and losses for the team in each season"""

import csv
import matplotlib.pyplot as plt

from ipl_lib import path
from ipl_lib import initials
from ipl_lib import all_seasons

path_to_directory = path()


def match_ids_of(team):
    """Returns a list of all the match ids of team"""
    match_ids = []
    with open(path_to_directory + '/ipl/matches.csv') as match_file:
        match_reader = csv.DictReader(match_file)
        for match in match_reader:
            if initials(match['team1']) == team:
                match_ids.append(match['id'])
            elif initials(match['team2']) == team:
                match_ids.append(match['id'])
            else:
                pass
    return match_ids


def get_matches_data_of(team):
    """Compiles the wins and losses into a dictionary"""
    match_ids = match_ids_of(team)

    stats_dict = {}

    with open(path_to_directory + '/ipl/matches.csv') as match_file:
        match_reader = csv.DictReader(match_file)

        id_index = 0

        while id_index < len(match_ids):

            for match in match_reader:
                if match['id'] == match_ids[id_index]:

                    season = match['season']

                    if season in stats_dict:

                        if initials(match['winner']) == team:
                            if match['win_by_runs'] == '0':
                                if 'successful_chase' in stats_dict[season]:
                                    stats_dict[season]['successful_chase'] += 1
                                else:
                                    stats_dict[season]['successful_chase'] = 1
                            else:
                                if 'successful_defense' in stats_dict[season]:
                                    stats_dict[season]['successful_defense'] += 1
                                else:
                                    stats_dict[season]['successful_defense'] = 1

                        elif initials(match['winner']) == 'Draw':
                            pass

                        else:
                            if 'losses' in stats_dict[season]:
                                stats_dict[season]['losses'] += 1
                            else:
                                stats_dict[season]['losses'] = 1

                    else:

                        stats_dict[season] = {}

                        if initials(match['winner']) == team:
                            if match['win_by_runs'] == '0':
                                stats_dict[season]['successful_chase'] = 1
                            else:
                                stats_dict[season]['successful_defense'] = 1

                        elif initials(match['winner']) == 'Draw':
                            pass

                        else:
                            stats_dict[season]['losses'] = 1

                    break

            id_index += 1

    return stats_dict


def compile_stats_of(team):
    """Compiles the extracted data into form of presentation"""
    seasons = all_seasons()
    stats_dict = get_matches_data_of(team)

    successful_chase = []
    successful_defense = []
    losses = []

    participated_in_seasons = []

    for season in seasons:
        if season in stats_dict:
            if 'successful_chase' in stats_dict[season]:
                successful_chase.append(stats_dict[season]['successful_chase'])
            else:
                successful_chase.append(0)
            if 'successful_defense' in stats_dict[season]:
                successful_defense.append(
                    stats_dict[season]['successful_defense'])
            else:
                successful_defense.append(0)
            if 'losses' in stats_dict[season]:
                losses.append(stats_dict[season]['losses'])
            else:
                losses.append(0)
            participated_in_seasons.append(season)

    return {'seasons': participated_in_seasons, 'successful_chase': successful_chase,
            'successful_defense': successful_defense, 'losses': losses}


def plot_performance_of(team):
    """Plots successful chases, successful defenses and losses of the team"""
    stats_dict = compile_stats_of(team)

    legends = ['Losses', 'Successful Defenses', 'Successful Chases']

    seasons = stats_dict['seasons']
    successful_chase = stats_dict['successful_chase']
    successful_defense = stats_dict['successful_defense']
    losses = stats_dict['losses']

    plt.bar(seasons, losses)
    plt.bar(seasons, successful_defense, bottom=losses)
    plt.bar(seasons, successful_chase, bottom=[
            x + y for x, y in zip(successful_defense, losses)])

    plt.title('Performance of {}'.format(team))
    plt.legend(legends)
    plt.xlabel('Seasons')
    plt.ylabel('No. of matches')
    plt.show()


plot_performance_of('MI')

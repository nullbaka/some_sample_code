def player_spot(click_position):
    x_pos, y_pos = click_position
    if x_pos < 200:
        x_spot = 0
        col = 0
    elif x_pos < 400:
        x_spot = 200
        col = 1
    elif x_pos < 600:
        x_spot = 400
        col = 2

    if y_pos < 200:
        y_spot = 0
        row = 0
    elif y_pos < 400:
        y_spot = 200
        row = 1
    elif y_pos < 600:
        y_spot = 400
        row = 2

    return ((x_spot, y_spot), row, col)

import pygame

def initialize():
    screen_width = 600
    screen_height = 600
    screen_size = (screen_width, screen_height)

    cell_width = int(screen_width/3)
    cell_height = int(screen_height/3)
    cell_size = (cell_width, cell_height)

    grid_image = pygame.image.load("grid.png")
    grid_image = pygame.transform.scale(grid_image, screen_size)

    x_image = pygame.image.load("x.png")
    x_image = pygame.transform.scale(x_image, cell_size)

    o_image = pygame.image.load("o.jpg")
    o_image = pygame.transform.scale(o_image, cell_size)

    game_window = pygame.display.set_mode((screen_size))

    return {'grid_image': grid_image, 'x_image': x_image, 'o_image': o_image,
            'game_window': game_window}

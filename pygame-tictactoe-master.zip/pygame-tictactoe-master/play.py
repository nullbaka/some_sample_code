
import pygame
from tictac_init import initialize
from players_cell import player_spot
from winner import check_win

pygame.init()

start = initialize()
grid_image = start['grid_image']
x_image = start['x_image']
o_image = start['o_image']
game_window = start['game_window']
pygame.display.set_caption("Tic.Tac.Toe")

def play():
    game_window.fill([255, 255, 255])
    game_window.blit(grid_image, (0, 0))
    player = True
    run = True
    played_positions = []
    grid_list = [[0 for i in range(3)] for i in range(3)]
    result = None

    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if not result:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    click_position = event.pos
                    play_position, row, col = player_spot(click_position)
                    if play_position not in played_positions:
                        played_positions.append(play_position)
                        if player:
                            game_window.blit(x_image, play_position)
                            player = False
                            grid_list[row][col] = 1
                        else:
                            game_window.blit(o_image, play_position)
                            player = True
                            grid_list[row][col] = 2
                    result = check_win(grid_list)
            elif result:
                myfont = pygame.font.SysFont("Comic Sans MS", 30)
                note = myfont.render(result, 1, [150, 150, 0])
                play_again = myfont.render("Click on the surface to play again.", 1, [150, 150, 0])
                game_window.fill([255, 255, 255])
                game_window.blit(note, (130, 230))
                game_window.blit(play_again, (70,280))
                if event.type == pygame.MOUSEBUTTONDOWN:
                    run = False
                    play()

            pygame.display.update()

play()

print('four')

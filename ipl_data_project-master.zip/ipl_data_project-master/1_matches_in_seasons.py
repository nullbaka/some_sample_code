"""This code plots all total no. of matches in each season"""

import csv

import matplotlib.pyplot as plt

from ipl_lib import path


def season_and_matches():
    """Extracts necessary data from matches.csv file"""
    PATH = path()
    all_matches = {}

    with open(PATH + '/ipl/matches.csv') as match_file:
        match_reader = csv.DictReader(match_file)
        for match in match_reader:
            season = match['season']
            if season in all_matches:
                all_matches[season] += 1
            else:
                all_matches[season] = 1

    return all_matches


def plot_seasons_and_matches():
    """plots the data received from the above function"""
    all_matches = season_and_matches()

    plt.bar(all_matches.keys(), all_matches.values())
    plt.title("No. of matches played each season")
    plt.xlabel("Season")
    plt.ylabel("No. of matches")
    plt.show()


plot_seasons_and_matches()

Python-3.7.4


Install requirements using 'pip install <moudule-name>':
Modules:
flask
flask-login
flask-wtf
flask-sqlalchemy
flask-migrate
flask-bootstrap

Create a '.flaskenv' in the app's home directory:
In it write 'FLASK_APP=goodreads.py' without the quotes ans save.

In your environment run the app using 'flask run'
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, ValidationError, Email, EqualTo, Required, Length
from app.models import User


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')


class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField(
        'Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')


class AddBookForm(FlaskForm):
    title = StringField('Title of the book', validators=[DataRequired(), Length(max=150)])
    author = StringField('author', validators=[Length(min=6, max=100)])
    summary = StringField('summary', validators=[Length(min=100, max=800)])
    genre = StringField('genre', validators=[DataRequired()])
    submit = SubmitField('Add Book')


class RateBookForm(FlaskForm):
    review = StringField('Review', validators=[Length(min=50, max=300)])
    submit = SubmitField('Submit')


class AboutAuthorForm(FlaskForm):
    about_author = TextAreaField('About Author', validators=[Length(max=800)], render_kw={"rows":4, "placeholder":"write something about the author"})
    submit = SubmitField('Submit')
"""Total wins by all the teams in all seasons"""

import csv
import matplotlib.pyplot as plt
from ipl_lib import path
from ipl_lib import initials
from ipl_lib import all_seasons


def get_winners():
    """Extract winners data from matches.csv into a dictionary"""
    winners_dict = {}
    path_to_directory = path()

    with open(path_to_directory + '/ipl/matches.csv') as matchfile:
        match_reader = csv.DictReader(matchfile)

        for match in match_reader:
            season = match['season']
            winner = initials(match['winner'])
            if winner is not 'Draw':
                if winner in winners_dict:
                    if season in winners_dict[winner]:
                        winners_dict[winner][season] += 1
                    else:
                        winners_dict[winner][season] = 1
                else:
                    winners_dict[winner] = {}
                    winners_dict[winner][season] = 1

    return winners_dict


def list_winners():
    """Transform dictionary into lists for stacked bar plot"""
    seasons = all_seasons()
    winners_dict = get_winners()
    teams = []
    each_teams_all_seasons = []
    all_teams_all_seasons = []

    for winner in winners_dict:
        teams.append(winner)
        for season in seasons:
            if season in winners_dict[winner]:
                each_teams_all_seasons.append(winners_dict[winner][season])
            else:
                each_teams_all_seasons.append(0)
        all_teams_all_seasons.append(each_teams_all_seasons)
        each_teams_all_seasons = []

    return (teams, all_teams_all_seasons)


def plot_winners_all_seasons():
    """Plot the winning count of all the teams for all seasons"""
    seasons = all_seasons()

    winners_list = list_winners()

    teams = winners_list[0]
    winners_through_seasons = winners_list[1]

    bottom = [0 for i in range(len(seasons))]

    for team_index in range(len(teams)):
        plt.bar(seasons, winners_through_seasons[team_index], bottom=bottom)
        bottom = [a + b for a,
                  b in zip(bottom, winners_through_seasons[team_index])]

    plt.title("Winners throughout the IPL seasons 2008-2017")
    plt.legend(teams)
    plt.xlabel("IPL Seasons")
    plt.ylabel("Matches Won")
    plt.show()

plot_winners_all_seasons()

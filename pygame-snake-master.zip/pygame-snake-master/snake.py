import random

class Snake():

    mode = 'closed'

    ROWS = 15
    COLS = 22

    START_ROW = int(ROWS/2)
    START_COL = int(COLS/2)

    start_body = [
        [START_ROW, START_COL],
        [START_ROW, START_COL+1],
        [START_ROW, START_COL+2],
        [START_ROW, START_COL+3]
    ]

    # body_length = len(body)

    new_head_row = None
    new_head_col = None
    old_tail_row = None
    old_tail_col = None
    food_row = None
    food_col = None
    mice_eaten = 0

    def __init__(self):
        self.field_array = [
            [0 for col in range(self.COLS)] for row in range(self.ROWS)]
        if self.mode == 'closed':
            for i in range(self.COLS):
                self.field_array[0][i] = 3
                self.field_array[self.ROWS-1][i] = 3
            for i in range(self.ROWS):
                self.field_array[i][0] = 3
                self.field_array[i][self.COLS-1] = 3
        self.body = self.start_body.copy()
        self.body_length = len(self.body)
        for row, col in self.body:
            self.field_array[row][col] = 1
        self.headed = 'left'
        self.generate_food()
        self.crash = 0
        self.mice_eaten = 0


    def body_update(self):
        self.body.insert(0, [self.new_head_row, self.new_head_col])

        if self.field_array[self.new_head_row][self.new_head_col] == 2:
            self.body_length += 1
            self.field_array[self.new_head_row][self.new_head_col] = 0
            self.generate_food()
            self.mice_eaten += 1
        else:
            self.old_tail_row, self.old_tail_col = self.body.pop()
            self.field_array[self.old_tail_row][self.old_tail_col] = 0

        self.field_array[self.new_head_row][self.new_head_col] = 1

    def move(self):
        if self.headed == 'up':
            self.move_up()
        elif self.headed == 'left':
            self.move_left()
        elif self.headed == 'down':
            self.move_down()
        elif self.headed == 'right':
            self.move_right()

    def turn_up(self):
        if self.headed is not 'down':
            self.headed = 'up'

    def turn_left(self):
        if self.headed is not 'right':
            self.headed = 'left'

    def turn_down(self):
        if self.headed is not 'up':
            self.headed = 'down'

    def turn_right(self):
        if self.headed is not 'left':
            self.headed = 'right'

    def move_up(self):
        self.new_head_row = self.body[0][0] - 1
        self.new_head_col = self.body[0][1]
        if self.field_array[self.new_head_row][self.new_head_col] in (1, 3):
            self.crash = 1
            return
        self.body_update()
        self.headed = 'up'

    def move_left(self):
        self.new_head_row = self.body[0][0]
        self.new_head_col = self.body[0][1] - 1
        if self.field_array[self.new_head_row][self.new_head_col] in (1, 3):
            self.crash = 1
            return
        self.body_update()
        self.headed = 'left'

    def move_down(self):
        self.new_head_row = self.body[0][0] + 1
        self.new_head_col = self.body[0][1]
        if self.field_array[self.new_head_row][self.new_head_col] in (1, 3):
            self.crash = 1
            return
        self.body_update()
        self.headed = 'down'

    def move_right(self):
        self.new_head_row = self.body[0][0]
        self.new_head_col = self.body[0][1] + 1
        if self.field_array[self.new_head_row][self.new_head_col] in (1, 3):
            self.crash = 1
            return
        self.body_update()
        self.headed = 'right'

    def generate_food(self):
        self.food_row = random.randint(0, self.ROWS - 1)
        self.food_col = random.randint(0, self.COLS - 1)
        if self.field_array[self.food_row][self.food_col] in (1, 3):
            self.generate_food()
        self.field_array[self.food_row][self.food_col] = 2

    def start_state(self):
        self.__init__()

def check_win(grid):

    result = None

    if grid[0][0] and grid[1][1] and grid[2][2]:
        if grid[0][0] == grid[1][1] == grid[2][2]:
            result = grid[1][1]

    if grid[0][2] and grid[1][1] and grid[2][0]:
        if grid[0][2] == grid[1][1] == grid[2][0]:
            result = grid[1][1]

    for j in range(3):
        if grid[0][j] and grid[1][j] and grid[2][j]:
            if grid[0][j] == grid[1][j] == grid[2][j]:
                result = grid[0][j]

    for i in range(3):
        if grid[i][0] and grid[i][1] and grid[i][2]:
            if grid[i][0] == grid[i][1] == grid[i][2]:
                result = grid[i][0]

    if result:
        return f"Congrats!! Player {result} won!"

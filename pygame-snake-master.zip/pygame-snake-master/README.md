My own take on the popular mobile retro game Snake.

Made with Pygame.

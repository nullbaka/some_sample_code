"""All necessary computations for the project"""
import re
from EventClass import Event


class MinColDiff(Event):
    """Contains methods for extraction and resolution of data"""

    def extract_col_diffs(self):
        """Read dat file and return a dictionary of sub-events and
           column differences as key value pairs"""
        differences = {}
        with open(self.path) as event_file:
            for event_row in event_file:
                event_row = event_row.strip().split()
                try:
                    col_a = int(
                        re.sub(r'\*', '', event_row[self.first_index]))
                    col_b = int(
                        re.sub(r'\*', '', event_row[self.second_index]))
                    row_head = event_row[self.query_index]
                    differences[row_head] = abs(col_a - col_b)
                except Exception:
                    pass
        return differences

    def min_valued_item(self):
        """Reads dictionary values and returns key value pairs of minimum value"""
        differences = self.extract_col_diffs()
        min_value = min(differences.values())

        min_valued_key = None

        for key, value in differences.items():
            if value == min_value:
                min_valued_key = key

        if self.event_name == 'football':
            print(f"{min_valued_key} has the minimum difference between for and against goals of {min_value}.")
        elif self.event_name == 'weather':
            print(f"The {min_valued_key}th day has the minimum temperature spread of {min_value} for the month.")

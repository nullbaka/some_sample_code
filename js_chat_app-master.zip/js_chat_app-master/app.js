var current_channel_id;
showAllChannels();
var username;


function showAllChannels() {
  const getChannelsRequest = new XMLHttpRequest();

  getChannelsRequest.open('GET', 'http://0.0.0.0:5000/channels');
  getChannelsRequest.send();
  getChannelsRequest.onload = showChannels;

  function showChannels() {
    const data = JSON.parse(this.responseText);
    var allChannels = document.querySelector('.allChannels');
    allChannels.innerHTML = '';
    for (let channel of data.resources) {
      var channelElement = document.createElement('div');
      channelElement.setAttribute("class", "channel");
      channelElement.setAttribute("id", channel.id);
      channelElement.innerHTML = channel.name;
      allChannels.appendChild(channelElement);
    }
  }
}


// DISPLAY MESSAGES OF CURRENT CHANNEL
function getMessages(target_channel) {

  const getMessagesRequest = new XMLHttpRequest();
  getMessagesRequest.open('GET', 'http://0.0.0.0:5000/messages/?channel_id=' + target_channel);
  getMessagesRequest.send();
  getMessagesRequest.onload = showMessages;

  function showMessages() {
    const data = JSON.parse(this.responseText);

    if (data) {

      var allMessages = document.querySelector('.allMessages');
      allMessages.innerHTML = '';
      for (let messageEntry of data.resources) {

        var msgDiv = document.createElement('div');
        msgDiv.setAttribute('class', 'msgDiv');
        var userDiv = document.createElement('div');
        userDiv.innerHTML = messageEntry.username + "____";
        var textDiv = document.createElement('div');
        textDiv.innerHTML = messageEntry.text;
        msgDiv.appendChild(userDiv);
        msgDiv.appendChild(textDiv);
        allMessages.appendChild(msgDiv);

      }
    }
  }
}



// CREATE NEW CHANNEL

var createBtn = document.getElementById('create');
if (createBtn) {
  createBtn.addEventListener('click', function() {
    console.log('create button clicked');
    var channelName = document.querySelector("#channelName").value;

    if (channelName) {

      let newChannel = JSON.stringify({
        name: channelName
      });

      let createChannel = new XMLHttpRequest();
      createChannel.open("POST", 'http://0.0.0.0:5000/channels/');
      createChannel.setRequestHeader('Content-type', 'application/json; charset=utf-8');
      createChannel.onload = function() {
        showAllChannels();
      }
      createChannel.send(newChannel);

    } else {
      console.log('channel name cannot be empty');
    }

    document.querySelector("#channelName").value = '';

  });
}

// SELECT CURRENT CHANNEL
var channels = document.querySelector('.allChannels');
if (channels) {
  channels.addEventListener('click', function(e) {
    var target = e.target.id;
    target = Number(target);
    getMessages(target);
    if (current_channel_id) {
      document.getElementById(current_channel_id).classList.remove('current');
    }
    current_channel_id = target;
    document.getElementById(current_channel_id).classList.add('current');

  });
}


// SEND NEW MESSAGE
var sendBtn = document.querySelector('#send');
if (sendBtn) {
  sendBtn.addEventListener('click', function() {
    var text = document.querySelector("#text").value;
    document.querySelector("#text").value = '';

    if (username && text && current_channel_id) {

      let newMsg = JSON.stringify({
        channel_id: current_channel_id,
        text: text,
        username: username
      });

      sendText(newMsg);

      broadcast(newMsg);
    }
  });
}


var typeOfPusher = (typeof Pusher);

if (typeOfPusher == 'function') {
  Pusher.logToConsole = true;
  var pusher = new Pusher('43c356772f00568df0ba', {
    cluster: 'ap2',
  });

  var channel = pusher.subscribe('messages');
  var eventName = 'message-added';


  channel.bind(eventName, function(data) {
    console.log('username:', data.username);
    console.log('text:', data.text);
    console.log('channel_id:', data.channel_id);

    var username = data.username;
    var text = data.text;
    var channel_id = data.channel_id;

    if (username && text && channel_id) {

      let newMsg = JSON.stringify({
        channel_id: channel_id,
        text: text,
        username: username
      });

      if (channel_id === current_channel_id) {
        var allMessages = document.querySelector('.allMessages');
        var msgDiv = document.createElement('div');
        msgDiv.setAttribute('class', 'msgDiv');
        var userDiv = document.createElement('div');
        userDiv.innerHTML = username + "____";
        var textDiv = document.createElement('div');
        textDiv.innerHTML = text;
        msgDiv.appendChild(userDiv);
        msgDiv.appendChild(textDiv);
        allMessages.appendChild(msgDiv);
      }
    }
  });
}


var login = document.getElementById('login');
if (login) {
  login.addEventListener('click', function() {
    username = document.getElementById('username').value;
    document.getElementById('username').value = '';
    if (username) {
      document.querySelector('.current_user').innerHTML = 'Hello, ' + username;
    } else {
      console.log('Username cannot be empty');
    }
  });
}


function broadcast(msg) {
  fetch('http://0.0.0.0:5000/broadcast', {
      method: 'POST',
      body: msg
    })
    .catch(err => console.log(err))
}


function sendText(msg) {
  let postRequest = new XMLHttpRequest();
  postRequest.open("POST", 'http://0.0.0.0:5000/messages/');
  postRequest.setRequestHeader('Content-type', 'application/json; charset=utf-8');
  postRequest.send(msg);
}
"""Repeat and Helper functions for ipl-data-project"""

import os
import csv

def path():
    """returns the path to the directory of the project"""
    return os.path.dirname(os.path.abspath(__file__))


def initials(fullname):
    """returns initials of a fullname"""
    if not fullname:
        return 'Draw'
    else:
        ini = ''
        for name in fullname.split():
            ini += name[0]
        return ini


def match_ids_of(season):
    """return match ids for the season"""
    path_to_directory = path()
    match_ids = []

    with open(path_to_directory + '/ipl/matches.csv') as match_file:
        match_reader = csv.DictReader(match_file)

        for match in match_reader:
            if match['season'] == season:
                match_ids.append(match['id'])

    return match_ids


def all_seasons():
    """Lists all the seasons of ipl from the matches.csv"""
    path_to_directory = path()
    seasons = []

    with open(path_to_directory + '/ipl/matches.csv') as match_file:
        match_reader = csv.DictReader(match_file)
        for match in match_reader:
            season = match['season']
            if season in seasons:
                pass
            else:
                seasons.append(season)

    return sorted(seasons, key=int)

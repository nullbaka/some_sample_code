print("five")

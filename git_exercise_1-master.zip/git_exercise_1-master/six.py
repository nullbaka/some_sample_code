print('six')

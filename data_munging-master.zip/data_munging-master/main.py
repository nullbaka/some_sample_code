"""Display output"""
from computation import MinColDiff

football = MinColDiff('football', 1, 6, 8)
football.min_valued_item()
weather = MinColDiff('weather', 0, 1, 2)
weather.min_valued_item()


A noob attempt at copying Goodreads website

Requirements:
flask
flask_login
flask_wtf
flask_sqlalchemy
flask_migrate

Functionalities added as of now:
Registration
Login
Browse
Add to read books
Add books by admin

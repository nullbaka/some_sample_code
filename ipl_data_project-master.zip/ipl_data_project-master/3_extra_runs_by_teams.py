"""Code to plot all the extras of all IPL seasons by all teams"""

import csv
import matplotlib.pyplot as plt

from ipl_lib import path
from ipl_lib import match_ids_of
from ipl_lib import initials


def extra_runs(season):
    """plotting extra runs of the season"""
    path_to_directory = path()
    match_ids = match_ids_of(season)

    extra_runs_by_teams = {}

    with open(path_to_directory + '/ipl/deliveries.csv') as delivery_file:
        delivery_reader = csv.DictReader(delivery_file)

        for delivery in delivery_reader:

            match_id = delivery['match_id']
            bowling_team = initials(delivery['bowling_team'])
            extra_runs = int(delivery['extra_runs'])

            if match_id in match_ids and delivery['is_super_over'] != '1':

                if bowling_team in extra_runs_by_teams:
                    extra_runs_by_teams[bowling_team] += extra_runs
                else:
                    extra_runs_by_teams[bowling_team] = extra_runs

    return extra_runs_by_teams


def plot_the_extras_by_teams(season):
    """Plots extras conceded by teams"""
    extra_runs_by_teams = extra_runs(season)

    plt.bar(extra_runs_by_teams.keys(), extra_runs_by_teams.values())
    plt.title('Extras conceded by teams in {}'.format(season))
    plt.xlabel('Teams')
    plt.ylabel('Extras')
    plt.show()


plot_the_extras_by_teams('2016')

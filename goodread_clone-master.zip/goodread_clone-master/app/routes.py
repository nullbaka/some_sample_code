from app import app, db
from flask import render_template, flash, redirect, url_for, request
from app.forms import LoginForm, RegistrationForm, AddBookForm, RateBookForm
from flask_login import current_user, login_user, logout_user, login_required
from app.models import User, Author, Book, Rating
from werkzeug.urls import url_parse


@app.route('/')
@app.route('/index')
@login_required
def index():
    return render_template('index.html', title="Recent updates")


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index')
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered user!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)


@app.route('/add_book', methods=['GET', 'POST'])
@login_required
def add_book():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    print('add a new book')
    form = AddBookForm()
    if form.validate_on_submit():
        author = Author.query.filter_by(author_name=form.author.data).first()
        book = Book.query.filter_by(title=form.title.data).first()
        if book is None:
            if author is None:
                author = Author(author_name=form.author.data)
                db.session.add(author)
                db.session.commit()
            book = Book(title=form.title.data, summary=form.summary.data, author=author)
            db.session.add(book)
            db.session.commit()
        else:
            if author is None:
                author = Author(author_name=form.author.data)
                db.session.add(author)
                db.session.commit()
                book = Book(title=form.title.data, summary=form.summary.data, author=author)
                db.session.add(book)
                db.session.commit()
        print('A new book has been added. Add another book?')
        return redirect(url_for('add_book'))
    return render_template('add_book.html', title="Add books", form=form)


@app.route('/explore')
def explore():
    books = Book.query.order_by(Book.book_id)
    return render_template('explore.html', title='Explore', books=books)


@app.route('/book/<book_title>/<author_id>', methods=['GET', 'POST'])
def book(book_title, author_id):
    book = Book.query.filter_by(title=book_title, author_id=author_id).first()
    form = RateBookForm()
    if form.validate_on_submit():
        review = Rating(user_id=current_user.id,
                        book_id=book.book_id, review=form.review.data)
        db.session.add(review)
        db.session.commit()
        return redirect(url_for('book', book_title=book.title, author_id=book.author.author_id))
    return render_template('book.html', title=book_title, book=book, form=form)


@app.route('/author/<author_name>')
def author(author_name):
    author = Author.query.filter_by(author_name=author_name).first()
    books = author.authored_books
    return render_template('author.html', title=author_name, author=author, books=books)


@app.route('/read/<title>/<author_id>')
@login_required
def read(title, author_id):
    flash("This book has been added to your read books")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.read(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))


@app.route('/wishlist/<title>/<author_id>')
@login_required
def wishlist(title, author_id):
    flash("This book has been added to your wishlist")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.wishlist(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))


@app.route('/now_reading/<title>/<author_id>')
@login_required
def now_reading(title, author_id):
    flash("This book has been added to your currently reading books")
    book = Book.query.filter_by(title=title, author_id=author_id).first()
    current_user.now_reading(book)
    return redirect(url_for('book', book_title=title, author_id=author_id))

import pygame as pg
from snake import Snake
import time

pg.init()

snake = Snake()

cell_width = 40

screen_width = cell_width * snake.COLS
screen_height = cell_width * snake.ROWS
screen_size = (screen_width, screen_height)

cell_size = (cell_width, cell_width)

body_image = pg.image.load("body.png")
body_image = pg.transform.scale(body_image, (cell_size))

food_image = pg.image.load("food.png")
food_image = pg.transform.scale(food_image, (cell_size))

game_window = pg.display.set_mode((screen_size))
pg.display.set_caption("Snake")


def draw_body():
    for snake_body in range(0, snake.body_length):
        body_position_y, body_position_x = snake.body[snake_body]
        body_position_x = body_position_x * cell_width
        body_position_y = body_position_y * cell_width
        game_window.blit(body_image, (body_position_x, body_position_y))


def draw_food():
    food_position_x = snake.food_col * cell_width
    food_position_y = snake.food_row * cell_width
    game_window.blit(food_image, (food_position_x, food_position_y))


def draw_boundary():
    boundary = pg.Rect(0, 0, screen_width, screen_height)
    pg.draw.rect(game_window, (100, 100, 100), boundary, cell_width * 2 - 10)


def game_over():
    time.sleep(0.3)
    game_window.fill([255, 255, 255])
    myfont = pg.font.SysFont("Comic Sans MS", 30)
    message_a = myfont.render(
        "Game Over.", 1, [150, 150, 0])
    message_b = myfont.render(
        f"You ate {snake.mice_eaten} mice.", 2, (150, 150, 0))
    message_c = myfont.render(
        "Press Y to play again. N to quit.", 3, (150, 150, 0))
    game_window.blit(message_a, (70, 100))
    game_window.blit(message_b, (70, 150))
    game_window.blit(message_c, (70, 200))
    pg.display.update()

    wait = True
    clock = pg.time.Clock()
    while wait:
        clock.tick(8)
        event = pg.event.wait()
        if event.type == pg.QUIT:
            pg.quit()
            exit()
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_y:
                snake.start_state()
                pg.init()
                play()
            elif event.key == pg.K_n:
                pg.quit()
                exit()


def play():
    run = True
    clock = pg.time.Clock()

    while run:
        clock.tick(8)
        game_window.fill([255, 255, 255])

        for event in pg.event.get():
            if event.type == pg.QUIT:
                run = False
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_LEFT:
                    snake.turn_left()
                elif event.key == pg.K_RIGHT:
                    snake.turn_right()
                elif event.key == pg.K_UP:
                    snake.turn_up()
                elif event.key == pg.K_DOWN:
                    snake.turn_down()

        draw_boundary()
        snake.move()
        draw_body()
        draw_food()
        pg.display.update()
        if snake.crash:
            game_over()


play()

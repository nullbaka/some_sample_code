print('three')

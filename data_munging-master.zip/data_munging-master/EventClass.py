"""Created a Grandfather class to instantiate events from"""
import os


class Event:
    """This is the Grandfather class written about in module docstring"""
    path_to_directory = os.path.dirname(os.path.abspath(__file__))

    def __init__(self, event_name, query_index, first_index, second_index):
        self.event_name = event_name
        self.query_index = query_index
        self.first_index = first_index
        self.second_index = second_index
        self.path = self.path_to_directory + '/' + self.event_name + '.dat'
